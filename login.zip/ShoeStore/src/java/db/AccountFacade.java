/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author HP
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import utils.DBUtils;



public class AccountFacade {

    public static Account login(String username, String password) {
        Account account = null;
        String sql = "SELECT * FROM Account WHERE username = ? AND password = ?";

        try (Connection conn = DBUtils.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    account = new Account(rs.getInt("id"), rs.getString("username"), rs.getString("password"), rs.getString("role"), rs.getInt("customerId"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return account;
    }
}
