/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import models.Cart;
import models.Item;
import models.User;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import storage.CartCache;
import storage.ItemCache;
import storage.UserCache;

/**
 *
 * @author usele
 */
public class Util {
    private static final String sqlUrl="jdbc:sqlserver://localhost;databaseName=SOLEMATE";
    private static final String sqlUser="sa";
    private static final String sqlPassword="12345";
    
    public Util(){
    }
    
    public static void terminalNotify(String s, boolean result) {
        if (result) {
            System.out.println("==================================================");
            System.out.println(s);
            System.out.println("==================================================");
        } else {
            System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            System.out.println(s);
            System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        }
    }
    
    public static Connection getConnection() {
        Connection conn= null;
        try {
            conn= DriverManager.getConnection(sqlUrl, sqlUser, sqlPassword);
            terminalNotify("SQL Connection Success", true);
        } catch (Exception e) {
            terminalNotify("SQL Connection Error: "+e.getMessage(), false);
        }
        return conn;
    }
    
    public static void sqlReadAll() {
        ArrayList<User> userAL= UserCache.getInstance();
        userAL.clear();
        String userQuery="SELECT * FROM USERS";
        
        ArrayList<Item> itemAL= ItemCache.getInstance();
        itemAL.clear();
        String itemQuery="SELECT * FROM ITEMS";
        
        ArrayList<Cart> cartAL= CartCache.getInstance();
        cartAL.clear();
        String cartQuery="SELECT * FROM CART";
        
        try {
            Connection con= getConnection();
            
            ResultSet rs= con.prepareStatement(userQuery).executeQuery();
            while (rs.next()) {
                userAL.add(new User(rs.getInt("userID"), rs.getString("userName"), rs.getString("userPass"), rs.getString("userRole")));
            }
            
            rs=con.prepareStatement(itemQuery).executeQuery();
            while (rs.next()) {
                itemAL.add(new Item(rs.getInt("itemID"),rs.getString("itemName"), rs.getString("itemDesc"),rs.getInt("itemStar"), rs.getFloat("itemPrice")));
            }
            
            rs=con.prepareStatement(cartQuery).executeQuery();
            while (rs.next()) {
                cartAL.add(new Cart(rs.getInt("userID"), rs.getInt("itemID"), rs.getInt("itemQuantity")));
            }
        } catch (Exception e) {
            terminalNotify("SQL Read Error: "+e.getMessage(), false);
        }
    }
    
    public static void sqlWrite(String query) {
        try {
            Connection con= getConnection();
            con.createStatement().executeUpdate(query);
            
            terminalNotify("SQL Write Success: "+query, true);
        } catch (Exception e) {
            terminalNotify("SQL Write Error: "+e.getMessage(), false);
        }
    }
    
    public static ArrayList sqlRead(String query) {
        ArrayList result=new ArrayList<>();
        try {
            Connection con= getConnection();
            ResultSet rs= con.prepareStatement(query).executeQuery();
            
            
            while (rs.next()) {
                result.add(rs);
            }
        } catch (Exception e) {
            terminalNotify("SQL Read Error: "+e.getMessage(), false);
        }
        return result;
    }
}
