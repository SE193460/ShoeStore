/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author usele
 */
public class User {
    private int userID;
    private String userName, userPass, userRole;
    
    public User() {
    }
    
    public User(int userID, String userName, String userPass, String userRole) {
        this.userID=userID;
        this.userName=userName;
        this.userPass=userPass;
        this.userRole=userRole;
    }
    
    public int getUserID() {return userID;}
    public String getUserName() {return userName;}
    public String getUserPass() {return userPass;}
    public String getUserRole() {return userRole;}
    
    public void setUserName(String userName) {this.userName=userName;}
    public void setUserPass(String userPass) {this.userPass=userPass;}
    public void setUserRole(String userRole) {this.userRole=userRole;}
    
    @Override
    public String toString() {
        return String.format("%d, %s, %s, %s", getUserID(), getUserName(), getUserPass(), getUserRole());
    }
}
