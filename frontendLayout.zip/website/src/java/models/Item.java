/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author usele
 */
public class Item {
    private int itemID, itemStar;
    private String itemName, itemDesc;
    private float itemPrice;
    
    public Item() {
    }
    
    public Item(int itemID, String itemName, String itemDesc, int itemStar, float itemPrice) {
        this.itemID=itemID;
        this.itemName=itemName;
        this.itemDesc=itemDesc;
        this.itemStar=itemStar;
        this.itemPrice=itemPrice;
    }
    
    public int getItemID() {return itemID;}
    public String getItemName() {return itemName;}
    public String getItemDesc() {return itemDesc;}
    public int getItemStar() {return itemStar;}
    public float getItemPrice() {return itemPrice;}
    
    public void setItemName(String itemName) {this.itemName=itemName;}
    public void setItemDesc(String itemDesc) {this.itemDesc=itemDesc;}
    public void setItemStar(int itemStar) {this.itemStar=itemStar;}
    public void setItemPrice(float itemPrice) {this.itemPrice=itemPrice;}
    
    @Override
    public String toString() {
        return String.format("%d, %s, %s, %d, %.2f", getItemID(), getItemName(), getItemDesc(), getItemStar(), getItemPrice());
    }
}
