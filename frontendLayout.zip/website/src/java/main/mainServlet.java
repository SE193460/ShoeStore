/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import utils.Util;

/**
 * Web application lifecycle listener.
 *
 * @author usele
 */
public class mainServlet implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        Util.sqlReadAll();
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
    }
}
