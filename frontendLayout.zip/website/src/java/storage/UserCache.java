/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package storage;

import java.util.ArrayList;
import models.User;

/**
 *
 * @author usele
 */
public class UserCache extends ArrayList<User> {
    private static UserCache instance;
    
    private UserCache() {
    }
    
    public static UserCache getInstance() {
        if (instance==null) {
            instance=new UserCache();
        }
        return instance;
    }
}
