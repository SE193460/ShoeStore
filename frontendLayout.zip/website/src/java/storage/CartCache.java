/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package storage;

import java.util.ArrayList;
import models.Cart;

/**
 *
 * @author usele
 */
public class CartCache extends ArrayList<Cart> {
    private static CartCache instance;
    
    private CartCache() {
    }
    
    public static CartCache getInstance() {
        if (instance==null) {
            instance=new CartCache();
        }
        return instance;
    }
}
