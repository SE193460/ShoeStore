/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PHT
 */
public class ProductFacade {

    private static final int page_size = 6;

    public List<Product> select() throws SQLException {
        List<Product> list = null;
        //Tạo kết nối db
        Connection con = DBContext.getConnection();
        //Tạo đối tượng Statement
        Statement stm = con.createStatement();
        //Thực thi lệnh select
        ResultSet rs = stm.executeQuery("select * from Product");
        list = new ArrayList<>();
        while (rs.next()) {
            //Đọc từng dòng trong table Brand để vào đối tượng product
            Product product = new Product();
            product.setId(rs.getInt("id"));
            product.setDescription(rs.getString("description"));
            product.setPrice(rs.getDouble("price"));
            product.setDiscount(rs.getDouble("discount"));
            product.setCategoryId(rs.getInt("categoryId"));
            //Thêm brand vào list
            list.add(product);
        }
        //Đóng kết nối db
        con.close();
        return list;
    }

    public List<Product> select(int page) throws SQLException {
        int pageSize = 6;
        List<Product> list = null;
        //Tạo kết nối db
        Connection con = DBContext.getConnection();
        //Tạo đối tượng Statement
        PreparedStatement stm = con.prepareStatement("select * from Product order by id offset ? rows fetch next ? rows only");
        stm.setInt(1, (page - 1) * pageSize);
        stm.setInt(2, pageSize);
        //Thực thi lệnh select
        ResultSet rs = stm.executeQuery();
        list = new ArrayList<>();
        while (rs.next()) {
            //Đọc từng dòng trong table Brand để vào đối tượng product
            Product product = new Product();
            product.setId(rs.getInt("id"));
            product.setDescription(rs.getString("description"));
            product.setPrice(rs.getDouble("price"));
            product.setDiscount(rs.getDouble("discount"));
            product.setCategoryId(rs.getInt("categoryId"));
            //Thêm brand vào list
            list.add(product);
        }
        //Đóng kết nối db
        con.close();
        return list;
    }

    public Product read(int id) throws SQLException {
        Product product = null;
        //Tạo kết nối db
        Connection con = DBContext.getConnection();
        //Tạo đối tượng Statement
        PreparedStatement stm = con.prepareStatement("select * from Product where id=?");
        stm.setInt(1, id);
        //Thực thi lệnh select
        ResultSet rs = stm.executeQuery();
        while (rs.next()) {
            //Đọc từng dòng trong table Brand để vào đối tượng product
            product = new Product();
            product.setId(rs.getInt("id"));
            product.setDescription(rs.getString("description"));
            product.setPrice(rs.getDouble("price"));
            product.setDiscount(rs.getDouble("discount"));
            product.setCategoryId(rs.getInt("categoryId"));
        }
        //Đóng kết nối db
        con.close();
        return product;
    }

    public int count() throws SQLException {
        int row_count = 0;
        //Tạo kết nối db
        Connection con = DBContext.getConnection();
        //Tạo đối tượng Statement
        Statement stm = con.createStatement();
        //Thực thi lệnh select
        ResultSet rs = stm.executeQuery("select count(*) row_count from Product");
        if (rs.next()) {
            row_count = rs.getInt("row_count");
        }
        //Đóng kết nối db
        con.close();
        return row_count;
    }

    public int countByQuery(String query) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Product WHERE description LIKE ?";

        // Use a connection to the database
        try (Connection conn = DBContext.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            // Set the query parameter for description and name
            stmt.setString(1, "%" + query + "%"); // Matching in description

            // Execute the query
            ResultSet rs = stmt.executeQuery();

            // If a result is found, return the count
            if (rs.next()) {
                return rs.getInt(1); // The count is in the first column
            }
            return 0; // If no results, return 0
        }
    }

    public List<Product> selectByQuery(String query, int page) throws SQLException {
        String sql = "SELECT * FROM Product WHERE description LIKE ? ORDER BY id OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

        // Calculate the offset for pagination
        int offset = (page - 1) * page_size;

        // Use a connection to the database
        try (Connection conn = DBContext.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            // Set the query parameter for description and name
            stmt.setString(1, "%" + query + "%"); // Matching in description

            stmt.setInt(2, offset); // Set the offset (for pagination)
            stmt.setInt(3, page_size); // Set the limit for page size

            // Execute the query
            ResultSet rs = stmt.executeQuery();

            // Create a list to store the products
            List<Product> list = new ArrayList<>();

            // Loop through the result set and map to Product objects
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setPrice(rs.getDouble("price"));
                product.setDiscount(rs.getDouble("discount"));
                product.setCategoryId(rs.getInt("categoryId"));
                product.setDescription(rs.getString("description"));
                list.add(product);
            }

            return list; // Return the list of products
        }
    }
}
