/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.util.Date;

/**
 *
 * @author HP
 */
public class OrderHeaderDTO {

    private int id;
    private Date date;
    private int customerId;
    private String status;

    public OrderHeaderDTO(int id, Date date, int customerId, String status) {
        this.id = id;
        this.date = date;
        this.customerId = customerId;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public Date getDate() {
        return date;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getStatus() {
        return status;
    }
}
