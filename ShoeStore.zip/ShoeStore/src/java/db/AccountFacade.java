/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import utils.Hasher;

/**
 *
 * @author PHT
 */
public class AccountFacade {

    public Account login(String email, String password) throws SQLException, NoSuchAlgorithmException {
        Account account = null;
        //Tạo kết nối db
        Connection con = DBContext.getConnection();
        //Tạo đối tượng Statement
        PreparedStatement stm = con.prepareStatement("select * from Account where email=? and password=?");
        stm.setString(1, email);
        stm.setString(2, Hasher.hash(password));
        //Thực thi lệnh select
        ResultSet rs = stm.executeQuery();
        if (rs.next()) {
            //Đọc dữ liệu vào đối tượng account
            account = new Account();
            account.setId(rs.getInt("id"));
            account.setEmail(rs.getString("email"));
            account.setPassword(rs.getString("password"));
            account.setFullname(rs.getString("fullname"));
            account.setRole(rs.getString("role"));
        }
        //Đóng kết nối db
        con.close();
        return account;
    }

    public boolean isEmailExist(String email) throws SQLException {
        String sql = "SELECT id FROM Account WHERE email=?";

        try (Connection con = DBContext.getConnection();
                PreparedStatement stm = con.prepareStatement(sql)) {

            stm.setString(1, email);
            try (ResultSet rs = stm.executeQuery()) {
                return rs.next(); // True if email exists
            }
        }
    }

    // **Register new user**
    public boolean register(Account account) throws SQLException, NoSuchAlgorithmException {
        if (isEmailExist(account.getEmail())) {
            return false; // Email already registered
        }

        String sql = "INSERT INTO Account (email, password, fullname, role) VALUES (?, ?, ?, 'user')";
        try (Connection con = DBContext.getConnection();
                PreparedStatement stm = con.prepareStatement(sql)) {

            stm.setString(1, account.getEmail());
            stm.setString(2, Hasher.hash(account.getPassword())); // Hash password
            stm.setString(3, account.getFullname());

            return stm.executeUpdate() > 0;
        }
    }

}
