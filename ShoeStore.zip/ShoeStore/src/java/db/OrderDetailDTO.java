/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author HP
 */
// OrderDetail DTO
public class OrderDetailDTO {

    private int id;
    private int orderHeaderId;
    private int productId;
    private int quantity;
    private double price;
    private double discount;

    public OrderDetailDTO(int id, int orderHeaderId, int productId, int quantity, double price, double discount) {
        this.id = id;
        this.orderHeaderId = orderHeaderId;
        this.productId = productId;
        this.quantity = quantity;
        this.price = price;
        this.discount = discount;
    }

    public int getId() {
        return id;
    }

    public int getOrderHeaderId() {
        return orderHeaderId;
    }

    public int getProductId() {
        return productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }

    public double getDiscount() {
        return discount;
    }
}
