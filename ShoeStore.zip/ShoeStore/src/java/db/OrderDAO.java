/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

/**
 *
 * @author HP
 */
import java.sql.*;
import java.util.*;

public class OrderDAO {

    public void createOrder(int customerId, List<OrderDetailDTO> details) throws SQLException {
        Connection conn = DBContext.getConnection();
        String insertOrder = "INSERT INTO OrderHeader (date, customerId, status) VALUES (?, ?, 'New')";
        String insertDetail = "INSERT INTO OrderDetail (orderHeaderId, productId, quantity, price, discount) VALUES (?, ?, ?, ?, ?)";

        try {
            conn.setAutoCommit(false);
            PreparedStatement ps = conn.prepareStatement(insertOrder, Statement.RETURN_GENERATED_KEYS);
            ps.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
            ps.setInt(2, customerId);
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int orderId = rs.getInt(1);
                ps = conn.prepareStatement(insertDetail);
                for (OrderDetailDTO detail : details) {
                    ps.setInt(1, orderId);
                    ps.setInt(2, detail.getProductId());
                    ps.setInt(3, detail.getQuantity());
                    ps.setDouble(4, detail.getPrice());
                    ps.setDouble(5, detail.getDiscount());
                    ps.executeUpdate();
                }
            }
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
            conn.close();
        }
    }

    public List<OrderHeaderDTO> getAllOrders() throws SQLException {
        List<OrderHeaderDTO> orders = new ArrayList<>();
        Connection conn = DBContext.getConnection();
        String sql = "SELECT * FROM OrderHeader ORDER BY date DESC";

        try (PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                orders.add(new OrderHeaderDTO(
                        rs.getInt("id"), rs.getTimestamp("date"),
                        rs.getInt("customerId"), rs.getString("status")
                ));
            }
        }
        return orders;
    }

    public void updateOrderStatus(int orderId, String status) throws SQLException {
        Connection conn = DBContext.getConnection();
        String sql = "UPDATE OrderHeader SET status = ? WHERE id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, orderId);
            ps.executeUpdate();
        }
    }

}
