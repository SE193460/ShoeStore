/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import db.Product;
import db.ProductFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author PHT
 */
@WebServlet(name = "ProductController", urlPatterns = {"/product"})
public class ProductController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = (String) request.getAttribute("action");
        switch (action) {
            case "index":
                //hiện danh sach toy
                index(request, response);
                break;
            case "search":
                search(request, response);
                break;
        }
    }

    protected void index(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int page_size = 6;
            //Lấy số trang
            HttpSession session = request.getSession();
            Integer page = (Integer) session.getAttribute("page");
            String spage = request.getParameter("page");
            if (spage != null) {
                page = Integer.parseInt(spage);
                session.setAttribute("page", page);
            }
            //Đọc table Toy
            ProductFacade pf = new ProductFacade();
            int row_count = pf.count();
            List<Product> list = pf.select(page);
            //Tính total_pages
            int total_page = (int) Math.ceil(row_count / page_size);
            request.setAttribute("total_page", total_page);
            //Lưu list vào request
            request.setAttribute("list", list);
            //Cho hiện view /toy.jsp
            request.getRequestDispatcher(Config.LAYOUT).forward(request, response);
        } catch (SQLException ex) {
            //in chi tiết exception
            ex.printStackTrace();
        }
    }

    protected void search(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int page_size = 5;
            // Get the current page number from the session or request
            HttpSession session = request.getSession();
            Integer page = (Integer) session.getAttribute("page");
            String spage = request.getParameter("page");
            if (spage != null) {
                page = Integer.parseInt(spage);
                session.setAttribute("page", page);
            }

            // Get the search query from the request
            String query = request.getParameter("query");

            // Create a ProductFacade instance to interact with the database
            ProductFacade pf = new ProductFacade();

            // Modify the query to account for the search parameter (if it exists)
            int row_count;
            List<Product> list;

            if (query != null && !query.trim().isEmpty()) {
                // Filter by name or type (description contains query)
                row_count = pf.countByQuery(query);
                list = pf.selectByQuery(query, page);
            } else {
                // If no search query, show all products
                row_count = pf.count();
                list = pf.select(page);
            }

            // Calculate total pages based on row count
            int total_page = (int) Math.ceil(row_count / (double) page_size);
            request.setAttribute("total_page", total_page);

            // Pass the list of products to the request
            request.setAttribute("list", list);

            // Set the search query in the request so the search form can be repopulated
            request.setAttribute("search_query", query);

            // Forward to the view
            request.getRequestDispatcher(Config.LAYOUT).forward(request, response);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

   

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
