package controllers;

import db.OrderDAO;
import db.OrderHeaderDTO;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Handles order management actions: list orders, update order status.
 */
@WebServlet(name = "OrderController", urlPatterns = {"/order"})
public class OrderController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        // Fix: Use getParameter instead of getAttribute
        String action = request.getParameter("action");
        if (action == null) action = "list"; // Default action

        switch (action) {
            case "list":
                list(request, response);
                break;
            case "update":
                update(request, response);
                break;
            default:
                response.sendRedirect(request.getContextPath() + "/error.jsp"); // Handle invalid actions
                break;
        }
    }

    protected void list(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            OrderDAO orderDAO = new OrderDAO();
            List<OrderHeaderDTO> orderList = orderDAO.getAllOrders();
            request.setAttribute("orderList", orderList);
            request.getRequestDispatcher("/WEB-INF/admin/order.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("message", "Error loading orders: " + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/admin/order.jsp").forward(request, response);
        }
    }

    protected void update(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int orderId = Integer.parseInt(request.getParameter("orderId"));
            String status = request.getParameter("status");

            OrderDAO orderDAO = new OrderDAO();
            orderDAO.updateOrderStatus(orderId, status);

            // Fix: Correct the redirect URL
            response.sendRedirect(request.getContextPath() + "/order?action=list");
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            request.setAttribute("message", "Error updating order: " + e.getMessage());
            request.getRequestDispatcher("/WEB-INF/admin/order.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Order Controller";
    }
}
