package cart;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Cart {

    private Map<Integer, Item> map;

    public Cart() {
        this.map = new HashMap<>();
    }

    public void add(Item item) {
        int id = item.getId();
        if (this.map.containsKey(id)) {
            // Nếu trong map đã có item thì tăng quantity
            Item currentItem = this.map.get(id);
            currentItem.setQuantity(currentItem.getQuantity() + item.getQuantity());
        } else {
            // Nếu trong map chưa có item thì thêm item vào map
            this.map.put(id, item);
        }
    }

    public Collection<Item> getItems() {
        return this.map.values();
    }

    public double getTotal() {
        return this.map.values().stream()
                .mapToDouble(Item::getCost)
                .sum();
    }

    public void empty() {
        this.map.clear();
    }

    public void remove(int id) {
        this.map.remove(id);
    }

    public void update(int id, int quantity) {
        Item item = this.map.get(id);
        if (item != null) {
            item.setQuantity(quantity);
        }
    }

}
